package com.internetbanking.carlos.internetbanking;

/**
 * Created by carlosrnjunior on 23/02/17.
 */
//// TODO: 23/02/17 Implementar
public class Deposito extends Transacao {
}
