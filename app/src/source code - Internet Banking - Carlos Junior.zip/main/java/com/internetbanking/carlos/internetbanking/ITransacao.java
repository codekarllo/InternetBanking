package com.internetbanking.carlos.internetbanking;

/**
 * Created by carlosrnjunior on 23/02/17.
 */

public interface ITransacao {

     void realizarTransacao();
}
