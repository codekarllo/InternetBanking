package com.internetbanking.carlos.internetbanking;

/**
 * Created by carlosrnjunior on 24/02/17.
 */

public enum TipoOperacao {
    CREDITO, DEBITO;
}
